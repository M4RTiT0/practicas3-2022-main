let usuarios = [
    {
        username:'its2022',
        correo:'its@gmail.com'
    },
    {
        username:'dvillegas',
        correo:'dvillegas@gmail.com'
    },
    {
        username:'jp2022',
        correo:'jp@gmail.com'
    }
]

usuarios.forEach(element => {
    console.log(element.username)
});