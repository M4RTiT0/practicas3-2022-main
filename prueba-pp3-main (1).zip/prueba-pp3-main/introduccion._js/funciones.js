//funcion tradicional
// ()= argumento de la funcion, dentro se alojan los parametros
function mostrar(mensaje){
    alert(mensaje)
}
//console.log('probando')

//aca ejecutamos la funcion
//mostrar()

function operar(){
const m = 'probando envio de parametros'
mostrar(m)
}