//caso 1

//estamos declarando e inicializando una variable
let numero = 10

if(numero == 10){
    numero = 22
    console.log(numero)
}
console.log(numero)


//caso 2
var numero2 = 55
if(numero2 == 55){
    var numero2 = 77
    console.log(numero2)
}
console.log(numero2)